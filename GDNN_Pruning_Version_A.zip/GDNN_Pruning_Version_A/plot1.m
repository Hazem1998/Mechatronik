time=ScopeData.time;
% plot(time,ScopeData.signals.values);
% xlabel('Zeit in s');
% ylabel('APRBS Signal');

% plot(time,data.signals.values(:,3),'b','linewidth',1.5);
% hold on
% plot(time,data.signals.values(:,2),'m','linewidth',1.2);
% axis([0 1.5 1.95 2.05]);
% xlabel('time in s');
% ylabel('Ausgang');
% legend('Ausgang System','Ausgang Modell');


% plot(time,data.signals.values(:,1),'r','linewidth',1.5);
% axis([0 3 0 1e-5]);
% xlabel('Zeit in s');
% ylabel('Kostenfunktion');
